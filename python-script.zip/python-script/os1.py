# Rename a file
import os

flname=input("Enter the file name you want to rename ")
nwname=input("Enter new file name ")
os.rename(flname, nwname)
