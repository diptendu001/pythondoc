# Exception handling

while True:
    n=0
    try:
        n = int(input("Enter any number "))
        m = int(input("Enter another number "))
        p = n / m
        print ("Result is ", p)
        break
    except ZeroDivisionError:
        print("Trying to divide by zero ")
    
    except Exception as e:
        print("Exception ",e)
        print("Type of exception ",type(e))
        break
    finally:
        print("Clean up job done here")

    
        
