# using file descripter attributes

fd=open("myfile.txt","r")
print("\nIs the file closed ? ", fd.closed)
print("\nThe file name ", fd.name)
print("\nFile opening mode ",fd.mode)
fd.close()
print("\nIs the file closed ? ", fd.closed)
