# creating a text file

fd=open("myfile.txt","a")
str1=input("Enter any string ")
fd.write(str1)
fd.close()

