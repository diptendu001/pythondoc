# Managing directories

import os

vardir=input("Enter directory name to create ")
os.mkdir(vardir)

os.chdir(vardir)

mypwd=os.getcwd()
print("\nCurrent directory is ",mypwd)

os.chdir("d:\python-script")
print("\nCurrent directory is ",os.getcwd())

os.rmdir(vardir)
