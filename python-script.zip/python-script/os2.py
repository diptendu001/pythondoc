# Remove a file
import os

flname=input("Enter the file name you want to remove ")
os.remove(flname)
