# Function using generator


def square_numbers(nums):
    for i in nums:
        yield(i*i)


my_nums=square_numbers([2,4,6,8])

print(next(my_nums))
print(next(my_nums))
print(next(my_nums))
print(next(my_nums))


