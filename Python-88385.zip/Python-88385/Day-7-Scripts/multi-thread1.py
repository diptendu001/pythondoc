import time

# Simple function excution without thread

def calc_square(numbers):
    print("Cacluate square ")
    for n in numbers:
        time.sleep(0.2)
        print ("Square : ", n*n)


def calc_cube(numbers):
    print("Cacluate cube ")
    for n in numbers:
        time.sleep(0.2)
        print ("Square : ", n*n*n)


arr=[2,3,4,5]

t=time.time()
calc_square(arr)
calc_cube(arr)

print("Done in ",time.time() - t)




