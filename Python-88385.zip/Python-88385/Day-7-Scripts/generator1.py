# Simple function and not generator is used


def square_numbers(nums):
    result = []
    for i in nums:
        result.append(i*i)
    return result

my_nums = square_numbers([2,4,6,8])
print(my_nums)



    