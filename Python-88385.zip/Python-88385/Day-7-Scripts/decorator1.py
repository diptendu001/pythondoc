# functions without using decorator

import time

def calc_square(numbers):
    start = time.time()
    result = []
    for number in numbers:
        result.append(number * number)
    end = time.time()
    print("Calc_square took " + str((end-start)*1000) + " mili seconds")
    return result

def calc_cube(numbers):
    start = time.time()
    result = []
    for number in numbers:
        result.append(number * number * number)
    end = time.time()
    print("Calc_cube took " + str((end-start)*1000) + " mili seconds")
    return result

arr = range(1,100000)
out_square = calc_square(arr)
out_cube = calc_cube(arr)
