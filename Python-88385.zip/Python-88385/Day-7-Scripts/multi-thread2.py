import time
import threading

# Simple function excution with thread

def calc_square(numbers):
    print("Cacluate square ")
    for n in numbers:
        time.sleep(0.2)
        print ("Square : ", n*n)


def calc_cube(numbers):
    print("Cacluate cube ")
    for n in numbers:
        time.sleep(0.2)
        print ("Cube : ", n*n*n)


arr=[2,3,4,5]

t=time.time()
# To create threads for the functions

t1=threading.Thread(target=calc_square,args=(arr,))
t2=threading.Thread(target=calc_cube,args=(arr,))

t1.start()
t2.start()

t1.join()
t2.join()

print("Done in ",time.time() - t)




