# Creating an empty class

class Employee:
      pass

