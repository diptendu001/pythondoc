#!/usr/bin/python

# Explains Built-In Class Attributes

class Student:
     'This is sample class declaration and usage'     
     def __init__(self, f_name, l_name):
         self.f_name = f_name
         self.l_name = l_name

     def show_stud(self):
          print ("First Name ",self.f_name)
          print ("Last Name ",self.l_name)

print ("\nClass documentation ",Student.__doc__)
print ("\nClass Name  ", Student.__name__)
print ("\nModule where class is defined [if any]",Student.__module__)
print ("\nDictionary hold namespace of the class",Student.__dict__)

