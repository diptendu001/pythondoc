#Constructor
#Self is the instance address, automatically passed whenever instance is created
#and constructor is executed


class Employee:
      def __init__(self, f,l,s):
          self.fname = f
          self.lname = l
          self.sal   = s
          self.email = f + '.' + l + '@wipro.com'
          print("Address hold in self ",self)
          


emp1 = Employee('Karla','Thomas',45000)
print("Address hold in emp1 ", emp1)
#emp2 = Employee('Dinesh','Negi',75000)


print(emp1.sal)
#print(emp2.s)
