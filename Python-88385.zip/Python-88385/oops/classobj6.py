#Accessing attributes using method
#in each method declaration, 'self' must be the first argument

class Employee:
      def __init__(self, fname,lname,sal):
          self.fname = fname
          self.lname = lname
          self.sal   = sal
          self.email = fname + '.' + lname + '@wipro.com'
          print ("self in const ",self)
          
      def disp_fullname(abc):
          print ("abc in disp function ",abc)
          return abc.fname + " " + abc.lname
          


emp1 = Employee('Karla','Thomas',45000)
print ("Address of emp1", emp1)
#emp2 = Employee('Dinesh','Negi',75000)

print(emp1.disp_fullname())
#print(emp2.disp_fullname())
