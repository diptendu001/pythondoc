#Instance variable
#Instance variables are unique per instance

class Employee:
      pass

emp1 = Employee()
emp2 = Employee()

#print(emp1)
#print(emp2)

emp1.f_name = "Karla"
emp1.l_name = "Thomas"
emp1.email = "karla.thomas@wipro.com"
emp1.sal = 45000

emp2.f_name = "Dinesh"
emp2.l_name = "Negi"
emp2.email = "dinesh.negi@wipro.com"
emp2.sal = 75000
emp2.city="Mumbai"

print(emp1.sal)
print(emp2.sal)
print(emp2.city)
