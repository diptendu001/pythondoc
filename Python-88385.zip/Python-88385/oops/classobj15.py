#!/usr/bin/python

# Class attribute manipulation functions

class Student:
     'This is sample class declaration and usage'     
     def __init__(self, f_name, l_name):
         self.f_name = f_name
         self.l_name = l_name

     def show_stud(self):
          print ("First Name ",self.f_name)
          print ("Last Name ",self.l_name)
          print ("Age ", self.age)
          print ("Roll ",self.roll)
          print ("Sex  ", self.sex)

student1 = Student("Anupam","Sarkar")


student1.age = 21
student1.roll = 150
student1.sex = 'Male'

student1.show_stud()

print ("is Roll attribute present ",hasattr(student1, 'roll'))
print ("Value in roll attribute is ",getattr(student1,'roll'))
print ("Changing the roll to 200 ", setattr(student1,'roll',200))
print ("Value in roll attribute is ",getattr(student1,'roll'))
print ("Deleting the roll attribute ",delattr(student1,'roll'))

student1.show_stud()


