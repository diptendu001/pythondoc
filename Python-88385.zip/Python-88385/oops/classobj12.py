# changing  value of class varibale in instance vs in class 

class Employee:
      num_of_emp = 0
      sal_hike = 300
      def __init__(self, fname,lname,sal):
          self.fname = fname
          self.lname = lname
          self.sal   = sal
          self.email = fname + '.' + lname + '@wipro.com'
          Employee.num_of_emp += 1  

      def disp_fullname(self):
          return self.fname + " " + self.lname

      def pay_hike(self):
#          self.sal = int(self.sal + Employee.sal_hike)
           self.sal = int(self.sal + self.sal_hike)     

emp1 = Employee('Karla','Thomas',45000)
emp2 = Employee('Dinesh','Negi',75000)
emp3 = Employee('Tanushri','Ghosh',95000)

print ("Total number os employees : ", Employee.num_of_emp)
