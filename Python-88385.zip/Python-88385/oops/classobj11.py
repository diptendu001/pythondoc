# changing  value of class varibale in instance vs in class 

class Employee:
      sal_hike = 300
      def __init__(self, fname,lname,sal):
          self.fname = fname
          self.lname = lname
          self.sal   = sal
          self.email = fname + '.' + lname + '@wipro.com'

      def disp_fullname(self):
          return self.fname + " " + self.lname

      def pay_hike(self):
#          self.sal = int(self.sal + Employee.sal_hike)
           self.sal = int(self.sal + self.sal_hike)     

emp1 = Employee('Karla','Thomas',45000)
emp2 = Employee('Dinesh','Negi',75000)
emp3 = Employee('Dipak','Das',95000)

emp1.sal_hike=500

#print(Employee.sal_hike)
#print(emp1.sal_hike)
#print(emp2.sal_hike)

Employee.sal_hike = 600

print(Employee.sal_hike)
print(emp1.sal_hike)
print(emp2.sal_hike)
