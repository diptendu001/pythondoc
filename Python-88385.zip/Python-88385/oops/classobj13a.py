# Regular method, class method, static method 
# class method as altarnet of constructor

class Employee:
      num_of_emp = 0
      sal_hike = 300
# Regular method
      def __init__(self, fname,lname,sal):
          self.fname = fname
          self.lname = lname
          self.sal   = sal
          self.email = fname + '.' + lname + '@wipro.com'
          Employee.num_of_emp += 1  

      def disp_fullname(self):
          return self.fname + " " + self.lname

      def pay_hike(self):
#          self.sal = int(self.sal + Employee.sal_hike)
           self.sal = int(self.sal + self.sal_hike)     
      @classmethod
      def set_hike_amount(cls, amount):
           cls.sal_hike = amount

      @classmethod
      def from_string(cls, emp_str):
          fname, lname, pay = emp_str.split('-')
          return cls(fname, lname, pay)

 



emp1 = Employee('Karla','Thomas',45000)
emp2 = Employee('Dinesh','Negi',75000)

emp_str_1='Amrita-Das-78000'
emp_Str_2='Tarun-Roy-68000'
emp_str_3='Javen-Ali-89000'

new_emp_1 = Employee.from_string(emp_str_1)

Employee.set_hike_amount(500)

print(new_emp_1.email)
print(new_emp_1.sal)
