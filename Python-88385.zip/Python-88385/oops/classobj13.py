# Regular method, class method, static method 

class Employee:
      num_of_emp = 0
      sal_hike = 300
# Regular method
      def __init__(self, fname,lname,sal):
          self.fname = fname
          self.lname = lname
          self.sal   = sal
          self.email = fname + '.' + lname + '@wipro.com'
          Employee.num_of_emp += 1  

      def disp_fullname(self):
          return self.fname + " " + self.lname

      def pay_hike(self):
#          self.sal = int(self.sal + Employee.sal_hike)
           self.sal = int(self.sal + self.sal_hike)     
      @classmethod
      def set_hike_amount(cls, amount):
           cls.sal_hike = amount

# in class method declaratin 'cls' refers the class like 'self' refers the 
# instance in regular method

emp1 = Employee('Karla','Thomas',45000)
emp2 = Employee('Dinesh','Negi',75000)

Employee.set_hike_amount(500)

print(Employee.sal_hike)
print(emp1.sal_hike)
print(emp2.sal_hike)