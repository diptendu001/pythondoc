# Regular method, class method, static method 
# Declaring and using static method

class Employee:
      num_of_emp = 0
      sal_hike = 300
# Regular method
      def __init__(self, fname,lname,sal):
          self.fname = fname
          self.lname = lname
          self.sal   = sal
          self.email = fname + '.' + lname + '@wipro.com'
          Employee.num_of_emp += 1  

      def disp_fullname(self):
          return self.fname + " " + self.lname

      def pay_hike(self):
#          self.sal = int(self.sal + Employee.sal_hike)
           self.sal = int(self.sal + self.sal_hike)     
      @classmethod
      def set_hike_amount(cls, amount):
           cls.sal_hike = amount

      @classmethod
      def from_string(cls, emp_str):
          fname, lname, pay = emp_str.split('-')
          return cls(fname, lname, pay)

      @staticmethod
      def is_workday(day):
           if day.weekday() == 5 or day.weekday() == 0:
               return False
           return True

 



emp1 = Employee('Karla','Thomas',45000)
emp2 = Employee('Dinesh','Negi',75000)

import datetime
my_date = datetime.date(2017, 11, 2)
print(Employee.is_workday(my_date))


