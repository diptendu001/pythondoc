#Accessing attributes using class name instead of instance name as prefix
# of method


class Employee:
      def __init__(self, fname,lname,sal):
          self.fname = fname
          self.lname = lname
          self.sal   = sal
          self.email = fname + '.' + lname + '@wipro.com'

      def disp_fullname(self):
          return self.fname + " " + self.lname



emp1 = Employee('Karla','Thomas',45000)
emp2 = Employee('Dinesh','Negi',75000)

print(emp1.disp_fullname())
print(dir(emp1))
print(Employee.disp_fullname(emp1))
print(dir(Employee))
