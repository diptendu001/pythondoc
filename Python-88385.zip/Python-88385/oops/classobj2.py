# Instanciate a class - create object

class Employee:
      pass

emp1 = Employee()
emp2 = Employee()

print(id(emp1))
print(id(emp2))

#help(emp1)
#print(emp1)
#print(emp2)
