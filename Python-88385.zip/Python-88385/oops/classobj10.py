# Using class varibale in the namespace

class Employee:
      sal_hike = 300
      def __init__(self, fname,lname,sal):
          self.fname = fname
          self.lname = lname
          self.sal   = sal
          self.email = fname + '.' + lname + '@wipro.com'

      def disp_fullname(self):
          return self.fname + " " + self.lname

      def pay_hike(self):
#          self.sal = int(self.sal + Employee.sal_hike)
           self.sal = int(self.sal + self.sal_hike)     

emp1 = Employee('Karla','Thomas',45000)
emp2 = Employee('Dinesh','Negi',75000)

#in the namespace of the instance the class
#variable will not be present
#But in namespace of the class the class 
#variable will be present
print("Namespace of instance emp1")
print(emp1.__dict__)
print("Namespace of instance Employee")
print(Employee.__dict__)

#print(Employee.sal_hike)
#print(emp1.sal_hike)
#print(emp2.sal_hike)
