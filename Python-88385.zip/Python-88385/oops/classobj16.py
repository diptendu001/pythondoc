#!/usr/bin/python


# Explains destructor

class Student:
    'This is sample class declaration and usage'     
    count=0
    def __init__(self, f_name, l_name):
        self.f_name = f_name
        self.l_name = l_name
        Student.count+=1

    def show_stud(self):
        print ("First Name ",self.f_name)
        print ("Last Name ",self.l_name)
        print ("Total students ", Student.count)

    def __del__(self):
        cname = self.__class__.__name__
        print (cname, "Destroyed")
        Student.count-=1

    def counter(self):
        print("Total number of members ", Student.count)

student1 = Student("Anupam","Sarkar")
student1.counter()
student2 = Student("Amrita","Singh")
student1.counter()
student3 = Student("Mayank","Agarwal")
student1.counter()

student1.show_stud()
student2.show_stud()
student3.show_stud()


print ("References of objects ")
print ("student1 => ",id(student1))
print ("student2 => ",id(student2))
print ("student3 => ",id(student3))

#print(Student.__dict__)

del student1
del student2
student2.counter()
del student3



#print ("References of objects ")
#print ("student1 => ",id(student1))
#print ("student2 => ",id(student2))
#print ("student3 => ",id(student3))