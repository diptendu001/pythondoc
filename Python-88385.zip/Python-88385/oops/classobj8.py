# Using class varibale. which is visible among all the instance of that 
# class


class Employee:
      sal_hike = 300
      def __init__(self, fname,lname,sal):
          self.fname = fname
          self.lname = lname
          self.sal   = sal
          self.email = fname + '.' + lname + '@wipro.com'

      def disp_fullname(self):
          return self.fname + " " + self.lname

      def pay_hike(self):
#          self.sal = int(self.sal + Employee.sal_hike)
           self.sal = int(self.sal + self.sal_hike)     

emp1 = Employee('Karla','Thomas',45000)
emp2 = Employee('Dinesh','Negi',75000)

print(emp1.sal)
emp1.pay_hike()
print(emp1.sal)

print(emp2.sal)
emp2.pay_hike()
print(emp2.sal)
