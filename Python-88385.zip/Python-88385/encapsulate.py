class Encapsulate:
    def __init__(self,a,b,c):
        self.public = a
        self._protected = b
        self.__private = c
