# creating a text file

fd=open("myfile.txt","w")
fd.write("Where there is a will \n")
fd.write("There is a way\n")
fd.close()

