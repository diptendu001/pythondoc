# Exception handling

while True:
    n=0
    try:
        n = int(input("Enter any number "))
        m = int(input("Enter another number "))
        p = n / m
        print ("Result is ", p)
    except ZeroDivisionError:
        print("Trying to divide by zero ")
    except ValueError:
        print("non-numeric value entered...try again")
    except Exception as e:
        print(e)
        print(type(e))
    else:
        print("There is no exception")
        break
      
    finally:
        print("Clean up job done here")

    
        
