# Reading specific number of characters from file

fd=open("myfile.txt","r")
text1=fd.read(10)
print("Text read from file ",text1)
pos=fd.tell()
print("Current file position ",pos)

pos=fd.seek(0,1)
print("Current file position ",pos)
text1=fd.read(22)
print("Text read from file ",text1)
fd.close()

