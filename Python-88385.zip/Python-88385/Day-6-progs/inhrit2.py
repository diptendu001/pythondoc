# Inheritance example

class Employee:
      
      sal_hike = 300

      def __init__(self, fname,lname,sal):
          self.fname = fname
          self.lname = lname
          self.sal   = sal
          self.email = fname + '.' + lname + '@wipro.com'
            

      def disp_fullname(self):
          return self.fname + " " + self.lname

      def pay_hike(self):
           self.sal = int(self.sal + Employee.sal_hike)


class Programmer(Employee):
      sal_hike = 400
      def __init__(self, fname,lname,sal,prog_lang):
           super().__init__(fname,lname,sal)
           self.prog_lang = prog_lang
           
prog1 = Programmer('Karla','Thomas',45000,'Java')
prog2 = Programmer('Dinesh','Negi',75000,'Ruby')

print(prog1.email)
print(prog1.prog_lang)

