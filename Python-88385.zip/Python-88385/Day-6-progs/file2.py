# Reading a text file

fd=open("myfile.txt","r")
text1=fd.read()
print("\n Content of the file is ")
print("\n")
print(text1)
fd.close()
