fl=open("myfile.txt","r+")
str1=fl.read(12)
print("Portion of file ", str1)

pos=fl.tell()
print("\nCurrent pointer position in file ", pos)

pos=fl.seek(0,0)
str1=fl.read(30)
print("Portion of text again ", str1)
fl.close()