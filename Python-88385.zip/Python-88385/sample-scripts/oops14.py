# inheritance - how to form child class

class Employee:
    sal_hike=500
    def __init__(self, f, l, s):
        self.f_name=f
        self.l_name=l
        self.email=self.f_name+"."+self.l_name+"@"+"testdomain.com"
        self.sal=s

    def disp_all(self):
        print("Full Name ", self.f_name+" "+self.l_name)
        print("Email Address ", self.email)
        print("Salary ", self.sal)

class Wt(Employee):
    pass


wt1=Wt("Maria","Brown",45000)
wt2=Wt("Deepak","Chahar",55000)

wt1.disp_all()
wt2.disp_all()


