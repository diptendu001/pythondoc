# Using Constructor
# self contains the address of an object

class Employee:
    def __init__(self, f, l, s):
        self.f_name=f
        self.l_name=l
        self.email=self.f_name+"."+self.l_name+"@"+"testdomain.com"
        self.sal=s
    

emp1 = Employee("Maria","Brown",45000)            
emp2 = Employee("Deepak","Chahar",55000)

print(emp1.email,emp1.sal)
print(emp2.email,emp2.sal)






