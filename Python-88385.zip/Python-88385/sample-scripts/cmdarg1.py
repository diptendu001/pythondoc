import sys

t=len(sys.argv)
print("total number of arguments ",t)
print("List of arguments ",sys.argv)


