# Rename a file

import os
srcfile=input("Enter the source file name ")
tgtfile=input("New file name ")
os.rename(srcfile, tgtfile)
