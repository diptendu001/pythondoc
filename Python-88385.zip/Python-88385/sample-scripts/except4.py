
try:
    n=int(input("Enter any number "))
    m=int(input("Enter another number "))
    res=n/m
    print("The result is ", res)
except ZeroDivisionError:
    print("Trying to divide by zero ")
except TypeError:
    print("Given non numeric value to divide ")
except NameError:
    print("Error with the value given to program")
except Exception as e:
        print("Error is ", e)
        print("Exception type ", type(e))
else:
    print("No exception, hence this block is executed")
finally:
        print("Clean up jobs done")


    
    
        