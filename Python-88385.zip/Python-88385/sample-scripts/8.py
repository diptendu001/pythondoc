# using infinite while loop

x=1
while True:
    x+=1
    if x<=8:
        continue
    print(x)
    if x==23:
        break

