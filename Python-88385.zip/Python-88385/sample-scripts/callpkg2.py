import sys
sys.path.append("C:\\Python-88385\\mypackage1")

from mypackage1 import *

x=int(input("Enter any number : "))
y=int(input("Enter another number : "))

print("Sum is : ", mymodule1.sum(x,y))
print("Difference is ", mymodule1.diff(x,y))
print("Product is ", mymodule2.prod(x,y))
print("Div result ", mymodule2.div(x,y))
 