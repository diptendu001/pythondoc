# Using default class attributes

class Employee:
    'This is a simple class decalaration'
    def __init__(self, f, l):
        self.fname=f
        self.laname=l


emp1 = Employee("Lio","Messi")            
emp2 = Employee("Cris", "Ronaldo")

print("\nClass document ", Employee.__doc__)
print("\nClass name ", Employee.__name__)
print("\nModule name where class is defined ", Employee.__module__)
print("\nDictionary that holds class info ", Employee.__dict__)










