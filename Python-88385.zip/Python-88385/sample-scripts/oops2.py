# Declare object of class

class Employee:
    pass


emp1 = Employee()            
emp2 = Employee()

print("Address of emp1 ", id(emp1))
print("Address of emp2 ", id(emp2))



