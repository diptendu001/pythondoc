
try:
    n=int(input("Enter any number "))
    m=int(input("Enter another number "))
    res=n/m
    print("The result is ", res)
except ZeroDivisionError:
        print("Trying to divide by zero ")
except Exception as e:
        print("Error is ", e)
        print("Exception type ", type(e))
finally:
        print("Clean up jobs done")


    
    
        