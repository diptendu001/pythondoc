# managing directory

import os
dirpath=input("Enter the directory path to create ")
os.mkdir(dirpath)

os.chdir(dirpath)

curdir=os.getcwd()
print("Current directory is ",curdir)

