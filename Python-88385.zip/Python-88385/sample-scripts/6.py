# Demo of Loops

x=1
while x <= 10:
    print(x)
    x+=1

print("\nComplete")

while x != 5:
    print(x)
    x-=1

print("\nComplete")
