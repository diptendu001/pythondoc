# Default instance methods

class Employee:
    sal_hike=500
    def __init__(self, f, l, s):
        self.f_name=f
        self.l_name=l
        self.email=self.f_name+"."+self.l_name+"@"+"testdomain.com"
        self.sal=s

    def disp_all(self):
        print("Full Name ", self.f_name+" "+self.l_name)
        print("Email Address ", self.email)
        print("Salary ", self.sal)

 
emp1 = Employee("Maria","Brown",45000)            
emp2 = Employee("Deepak","Chahar",55000)

print("is Sal present ", hasattr(emp1,'sal'))
print("what is the value of sal of employee 1 ", getattr(emp1,'sal'))
#change the value of salary
setattr(emp1,'sal',60000)
print("what is the value of sal of employee 1 ", getattr(emp1,'sal'))
delattr(emp1,'sal')
print("is Sal present ", hasattr(emp1,'sal'))





