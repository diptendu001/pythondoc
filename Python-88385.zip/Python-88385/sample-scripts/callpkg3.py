import sys
sys.path.append("C:\\Python-88385\\mypackage1")

from mypackage1 import *

x=int(input("Enter any number : "))
y=int(input("Enter another number : "))

print("Sum is : ", sum(x,y))
print("Difference is ", diff(x,y))
print("Product is ", prod(x,y))
print("Div result ", div(x,y))
 