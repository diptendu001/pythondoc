# Declaring and using class variables

class Employee:
    sal_hike=500
    def __init__(self, f, l, s):
        self.f_name=f
        self.l_name=l
        self.email=self.f_name+"."+self.l_name+"@"+"testdomain.com"
        self.sal=s

    def disp_all(self):
        print("Full Name ", self.f_name+" "+self.l_name)
        print("Email Address ", self.email)
        print("Salary ", self.sal)

    def pay_hike(self):
#        self.sal = int(self.sal + Employee.sal_hike)
        self.sal = int(self.sal + self.sal_hike)       

emp1 = Employee("Maria","Brown",45000)            
emp2 = Employee("Deepak","Chahar",55000)
emp1.pay_hike()
emp2.pay_hike()
emp1.disp_all()
emp2.disp_all()







