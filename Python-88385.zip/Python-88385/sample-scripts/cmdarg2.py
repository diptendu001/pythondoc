import sys

if len(sys.argv) < 2:
    print("Insufficient number of arguments ")
    print("Enter two numbers separated by space along with command ")
    print("Example ", sys.argv[0], "num1 num2")
else:
    if len(sys.argv) == 2:
        print ("One parameter is not enough ")    
        exit
    if len(sys.argv) == 3:
        a=int(sys.argv[1])
        b=int(sys.argv[2])
        print("Product is ", a*b)





