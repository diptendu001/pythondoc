# understanding conditional statements

x=int(input("Enter any number "))
if x % 2 == 0:
    if x > 20:
        print("Number is more than twenty")
    print("Even")
else:
    print("Odd")


