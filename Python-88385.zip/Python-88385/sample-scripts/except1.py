p=21
while True:
    n=0
    try:
        n=int(input("Enter any number "))
        m=p/n
        print("The value of m is ", m)
        break
    except ZeroDivisionError:
        print("Trying to divide by zero ")
    except ValueError:
        print("non-numeric value entered ... try again")
    except:
        print("Unknown error ... try again")
    finally:
        print("Clean up jobs done")


    
    
        