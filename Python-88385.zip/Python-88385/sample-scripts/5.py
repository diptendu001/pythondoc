# Multiple conditions

x=int(input("Enter any number : "))
if x == 1:
    print("One")
elif x == 2:
    print("Two")
elif x == 3:
    print("Three")
else:
    print("Don't know")




