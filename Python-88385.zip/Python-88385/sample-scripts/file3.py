# Create a text file

fa=open("myfile.txt","a")
str1=input("Enter any string ")
fa.write("\n" + str1)
fa.close()

