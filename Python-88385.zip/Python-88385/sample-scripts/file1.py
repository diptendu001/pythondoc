# Create a text file

fw=open("myfile.txt","w")
fw.write("we are learning python")
fw.close()

