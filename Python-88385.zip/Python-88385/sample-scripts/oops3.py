# Using instance variables

class Employee:
    pass


emp1 = Employee()            
emp2 = Employee()

emp1.f_name="Maria"
emp1.l_name="Brown"
emp1.email="maria.brown@testdomain.com"
emp1.sal=45000

emp2.f_name="Deepak"
emp2.l_name="Chahar"
emp2.email="deepak.chahar@testdomain.com"
emp2.sal=55000

print(emp1.email)
print(emp2.sal)






