# understanding conditional statements

x=int(input("Enter any number "))
if x % 2 == 0:
    print("Even")
else:
    print("Odd")


