# Create a text file

fr=open("myfile.txt","r")
str1=fr.read()
print("File content \n")
print(str1)
fr.close()

