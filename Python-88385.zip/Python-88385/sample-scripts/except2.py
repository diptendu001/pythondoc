import sys

try:
    fn=open("myfile.txt") 
    txt1=fn.readline() 
    print("The content of file : ", txt1)
    num=int(txt1)
except IOError:
    print("Error reading or opening file ")
except ValueError:
    print("Could not convert data to an integer ")
except:
    print("Unknown Error ")
finally:
    print("Clean up done")

    
