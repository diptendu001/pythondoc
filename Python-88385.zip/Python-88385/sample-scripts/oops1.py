# Declare emply class

class Employee:
    pass
