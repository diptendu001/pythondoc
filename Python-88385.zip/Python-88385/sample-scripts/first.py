# This is a sample script
print("Hello World")
a=20
b=10
# unformatted output statement
print("The value of a and b is ", a,b)
# formatted output
print("%d and %d is the value of a and b " % (a,b))

