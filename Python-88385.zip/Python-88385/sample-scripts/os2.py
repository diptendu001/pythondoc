# Rename a file

import os
srcfile=input("Enter the filename to delete ")
os.remove(srcfile)

