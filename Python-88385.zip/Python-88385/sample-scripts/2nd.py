# Using input and output statements

a=int(input("Enter any number "))
b=int(input("Enter another number "))
fnm=input("Enter first name ")
lnm=input("Enter last name ")
# unformatted output statement
print("The value of a and b is ", a,b)
# formatted output
print("%4d and %4d is the value of a and b " % (a,b))
print("\nYour name is %s  %s " % (fnm,lnm))
fullname=fnm+" "+lnm
print("\nFull name ", fullname)


