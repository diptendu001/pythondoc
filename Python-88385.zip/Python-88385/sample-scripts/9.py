for x in range(5):
    print("Wipro")

for x in range(2,10,2):
    print(x)
