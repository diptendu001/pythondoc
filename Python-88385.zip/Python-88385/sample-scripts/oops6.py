# Self is not a reserve word, any other word can be used
# but that must be the first parameter or only parameter

class Employee:
    def __init__(addr, f, l, s):
        addr.f_name=f
        addr.l_name=l
        addr.email=addr.f_name+"."+addr.l_name+"@"+"testdomain.com"
        addr.sal=s

    def disp_all(addr):
        print("Full Name ", addr.f_name+" "+addr.l_name)
        print("Email Address ", addr.email)
        print("Salary ", addr.sal)
    

emp1 = Employee("Maria","Brown",45000)            
emp2 = Employee("Deepak","Chahar",55000)
emp1.disp_all()
emp2.disp_all()






