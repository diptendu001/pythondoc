import sys
sys.path.append("C:\\Python-88385\\mymodules")

from mymodule1 import sum as SUM 
from mymodule2 import prod as PROD


a=int(input("Enter any number : "))
b=int(input("Enter another number : "))
s=SUM(a,b)
p=PROD(a,b)
print("Sum is ", s)
print("Product is ", p)



