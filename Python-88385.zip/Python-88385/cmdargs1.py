# Testing command line arguments

import sys

print("Environment string ", str(sys.argv))
print("Script name is ", sys.argv[0])
print("Total number of arguments entered ", len(sys.argv))
