import sys
sys.path.append("C:\\Python-88385\\mymodules")

import mymodule1
import mymodule2


a=int(input("Enter any number : "))
b=int(input("Enter another number : "))
s=mymodule1.sum(a,b)
p=mymodule2.prod(a,b)
print("Sum is ", s)
print("Product is ", p)

