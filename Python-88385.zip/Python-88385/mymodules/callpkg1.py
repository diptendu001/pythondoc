import sys
sys.path.append("mypackage1")

import mypackage1

a=int(input("Enter any number "))
b=int(input("Enter another number "))
s=mypackage1.mymodule1.sum(a,b)
p=mypackage1.mymodule2.prod(a,b)

print("Sum of the numbers ", s)
print("Product of the nmbers ", p)



