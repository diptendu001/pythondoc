import sys
sys.path.append("mypackage1")

from mypackage1 import *

a=int(input("Enter any number "))
b=int(input("Enter another number "))
s=sum(a,b)
p=prod(a,b)

print("Sum of the numbers ", s)
print("Product of the nmbers ", p)



