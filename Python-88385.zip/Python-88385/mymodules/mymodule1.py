def sum(a,b):
    return a+b

def diff(a,b):
    return a-b



