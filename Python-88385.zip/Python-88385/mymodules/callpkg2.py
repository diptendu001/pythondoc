import sys
sys.path.append("mypackage1")

from mypackage1 import *

a=int(input("Enter any number "))
b=int(input("Enter another number "))
s=mymodule1.sum(a,b)
p=mymodule2.prod(a,b)

print("Sum of the numbers ", s)
print("Product of the nmbers ", p)



