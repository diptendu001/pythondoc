fw=open("myfile1.txt","a")
fw.write("\nThis is a new line ")
fw.close()

