# Creating text file

fw=open("myfile1.txt","w")
fw.write("Where there is a will ")
fw.write("\nThere is a way ")
fw.close()

fr=open("myfile1.txt","r")
text1=fr.read()
print("Content of the file \n", text1)
fr.close()




