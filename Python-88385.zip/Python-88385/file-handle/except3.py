
while True:
    n=21
    try: 
        m=int(input("Enter any number "))
        p=n/m
        print("Result is ",p)
    except ZeroDivisionError:
        print("Trying to divide by zero ")
    except Exception as e:
        print("The Exception is ",e)
        print("The type of exception is ", type(e))
        break
    else:
        print("There is no exception")
    finally:
        print("system clean up done here ")

    
