fl=open("myfile2.txt", "r+")
text1=fl.read(15)
print(text1)

curr_pos=fl.tell()
print("Current pointer in file ",curr_pos)

pos=fl.seek(0,0)
text1=fl.read(25)
print(text1)

