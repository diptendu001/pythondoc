
while True:
    n=21
    try: 
        m=int(input("Enter any number "))
        p=n/m
        print("Result is ",p)
        break
    except ZeroDivisionError:
        print("Trying to divide by zero ")
    except ValueError:
        print("non-number entered ")
    except:
        print("Unknown error ")
        break
    finally:
        print("system clean up done here ")

    
