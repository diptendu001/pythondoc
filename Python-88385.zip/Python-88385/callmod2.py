import sys
sys.path.append("C:\\Python-88385\\mymodules")

from mymodule1 import * 
from mymodule2 import *


a=int(input("Enter any number : "))
b=int(input("Enter another number : "))
s=sum(a,b)
p=prod(a,b)
print("Sum is ", s)
print("Product is ", p)
print("Difference is ", diff(a,b))
print("Div result is ", div(a,b))


